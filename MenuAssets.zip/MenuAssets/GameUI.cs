﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameUI : MonoBehaviour {

	public Image fadePlane;
	public GameObject gameOverUI;




		void OnGameOver(){
		Cursor.visible = true;
		StartCoroutine (Fade (Color.clear, new Color(0,0,0,.9f),1));
			

		//healthBar.transform.parent.gameObject.SetActive (false);
		gameOverUI.SetActive (true);	
	}


	IEnumerator Fade(Color from, Color to, float time){
		float speed =1/time;
		float percent = 0;

		while (percent<1) {
			percent += Time.deltaTime * speed;
			fadePlane.color = Color.Lerp (from, to, percent);
			yield return null;
		}
	}

	//UI input
	public void StartNewGame(){
		
		SceneManager.LoadScene ("integration");

	}

	public void ReturnToMainMenu(){
		SceneManager.LoadScene ("Menu");

	}



}