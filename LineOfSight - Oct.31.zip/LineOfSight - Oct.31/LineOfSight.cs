﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineOfSight : MonoBehaviour {

	public Material material1;	//default material
	public Material material2;	//secondary material for swap
	bool firstMaterial = true;
	bool secondMaterial = false;

	// Use this for initialization
	void Start () {
		
	}
		
	RaycastHit hit;
	public Transform target;
	void Update () {
		
			target.GetComponent<Renderer>().material = material1;	//set material to default
			firstMaterial = true;
			secondMaterial = false;


		if (Physics.Linecast (transform.position, target.position, out hit))	//send linecast toward target position
		if (hit.collider.gameObject.tag == "enemy") {	//check to see if target is in view
			Debug.DrawLine (transform.position, target.position, Color.red);

			if (firstMaterial = true) {
				target.GetComponent<Renderer>().material = material2;	//set material to secondary
				secondMaterial = true;
				firstMaterial = false;
			}
			print("You can attack");

		}
	}
}