﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitTraits : ScriptableObject {

	public enum UnitSelectionStatus { NotSelected, Movement, LoS }
}
