************************************
IMPORTANT
************************************

************************************ 
INSTALLATION
************************************

Please read the documentation pdf "NavMeshExtension"
for a quick start guide and further information.

************************************ 
SUPPORT
************************************ 

For support queries, visit our support forum or drop us a line.
To support us, please consider writing a review on the Asset
Store. The corresponding links are located in the top menu
under Window > NavMesh Extension > About. Thank you!

************************************ 